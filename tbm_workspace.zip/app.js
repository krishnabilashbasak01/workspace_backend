require("dotenv").config();
const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const morgan = require("morgan");
const helmet = require("helmet");
const http = require("http");
const { Server } = require("socket.io");
const Redis = require("ioredis");
const { PrismaClient } = require("@prisma/client");
const prisma = new PrismaClient();

// Import routes and middleware
const authRoutes = require("./routes/auth.routes");
const userRoutes = require("./routes/user.routes");
const roleRoutes = require("./routes/role.routes");
const clientRoutes = require("./routes/client.routes");
const socialMediaPlatformsRoutes = require("./routes/socialmediaplatforms.routes");
const calendarRoutes = require("./routes/calendar.routes");
const packageRoutes = require("./routes/package.routes");
const taskRoutes = require("./routes/task.route");

const errorHandler = require("./middlewares/errorHandler");
const { MONGO_URI } = require("./config/db.config");
const { getUserById } = require("./controllers/user.controller");
const {
  createTask,
  getTasksByClientAndDate,
  updateTask,
  getTasks,
  getTasksByIdList,
  getTaskById,
  updateTaskStatus,
  saveMessage,
} = require("./controllers/task.controller");
const { resolve } = require("path");

const app = express();

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(morgan("combined"));
app.use(helmet());

// Connect to MongoDB
mongoose
  .connect(MONGO_URI, {})
  .then(() => {
    console.log("MongoDB Connected");
  })
  .catch((err) => console.error(err));

// Routes
app.use("/api/", authRoutes);
app.use("/api/users", userRoutes);
app.use("/api/roles", roleRoutes);
app.use("/api/client", clientRoutes);
app.use("/api/social-media-platforms", socialMediaPlatformsRoutes);
app.use("/api/calendar", calendarRoutes);
app.use("/api/package", packageRoutes);
app.use("/api/task", taskRoutes);
// Error Handler
app.use(errorHandler);

const PORT = process.env.PORT || 3000;

// Server listener
// app.listen(PORT, () => console.log(`Server started on port ${PORT}`));

// Redis// Set up Redis connection (assuming Redis is locally running)
const redis = new Redis({
  username: "default",
  password: "0Hgvu2Ink483EdXtTKgYPlId8DepKlcy", // specify if Redis requires authentication
  host: "redis-16679.crce179.ap-south-1-1.ec2.redns.redis-cloud.com", // replace with your Redis host if different
  port: 16679, // default Redis port
  db: 0, // default database in Redis
});

// New socket server change
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST", "PUT", "DELETE"],
  },
});

io.on("connection", (socket) => {
  // console.log("New user connected", socket.id);

  // Example event handler
  socket.on("message", (data) => {
    // console.log('Received message:', data);
    // Echo the message back to the client
    socket.emit("message", `Server received: ${data}`);
  });

  // Listen for the "user_connected" event
  socket.on("user_connected", async (data) => {
    const { userId } = data;

    try {
      await redis.set(`user:${userId}`, socket.id);
    } catch (err) {
      console.error("Error storing in Redis:", error);
    }

    // Emit 'user_status' to notify all other users of this new connection
    // socket.broadcast.emit('user_status', { userId, status: 'online' });
    const user = await getUserById(userId);

    socket.broadcast.emit("new_user_connected", user);
    socket.emit("message", `Server received: ${userId}`);

    const keys = await redis.keys("user:*");
    let _users = [];
    for (const key of keys) {
      const id = key.split(":")[1];
      _users.push(id);
    }
    io.emit("online_users", _users);
  });

  socket.on("get_online_users", async (data) => {
    const keys = await redis.keys("user:*");
    let _users = [];
    for (const key of keys) {
      const id = key.split(":")[1];
      _users.push(id);
    }
    io.emit("online_users", _users);
  });

  // task
  // Create Task
  socket.on("create_task", async (data, callback) => {
    try {
      const {
        clientId,
        title,
        postTypeId,
        calendarEntryIds,
        scheduleDate,
        statusId,
        designerId,
        workDate,
        postLinks,
        postFromHome,
      } = data;
      // console.log(data);

      let task = await createTask(
        clientId,
        title,
        postTypeId || null,
        calendarEntryIds || [],
        scheduleDate,
        statusId,
        designerId || null,
        workDate || null,
        postLinks || [],
        postFromHome || false
      );
      if (task) {
        const tasks = await getTasksByClientAndDate(clientId, scheduleDate);
        io.emit("task_creation_response", {
          message: "New Task Created",
          tasks: tasks,
        });
        callback({ status: "success", message: "Task Successfully Created" });
      } else {
        socket.emit("task_creation_response", { error: "Task Creation Error" });
        callback({ status: "error", message: "Task Creation Error" });
      }
    } catch {
      callback({ status: "error", message: "Task Creation Error" });
    }
  });

  // Update Task
  socket.on("update_task", async (data) => {
    try {
      const task = await updateTask(data);
      if (task) {
        const tasks = await getTasksByClientAndDate(
          task.clientId,
          task.scheduleDate
        );
        console.log("task", task);
        let _userData = {};
        _userData.userType = user.role.name;
        _userData.userId = user._id;
        const _tasks = await getTasks(_userData);
        socket.emit("receive_tasks", tasks);

        io.emit("task_creation_response", {
          message: "Task Updated",
          tasks: tasks,
        });
      } else {
        socket.emit("task_creation_response", { error: "Task Update Error" });
      }
    } catch (err) {
      console.log(err.message);
    }
  });

  // sme and admin tasks
  socket.on("get_tasks", async (data) => {
    // const {userType, date = null} = data;
    const tasks = await getTasks(data);

    socket.emit("receive_tasks", tasks);
  });

  // socket set task to designer bucket
  socket.on("set_task_on_bucket", async (data, callback) => {
    try {
      await addTaskToDesignerBucket(data);
      await getDesignerBucket({ designerId: data.task.designerId });
      await getSmeBucket({ smeId: data.user.smeId });
    } catch (error) {
      callback({ status: "error", message: "Failed task add to bucket" });
    } finally {
      callback({ status: "success", message: "Task Added to bucket" });
    }
    
  });

  //   get tasks of user in queue
  socket.on("get_tasks_in_queue", async (data, callback) => {
    try {
      const { role, id, head } = data;
      if (role.toLowerCase() === "sme") {
        if (head) {
          // get all
          getAllBucket();
        }
        await getSmeBucket({ smeId: id });
      } else if (role.toLowerCase() === "ve" || role.toLowerCase() === "gd") {
        await getDesignerBucket({ designerId: id });
      } else if (
        role.toLowerCase() === "admin" ||
        role.toLowerCase() === "super admin"
      ) {
        // get all
        getAllBucket();
      }
    } catch (error) {
      callback({ status: "error", message: "Get task in queue failed" });
    } finally {
      callback({
        status: "success",
        message: "Task in queue get successfully",
      });
    }
  });

  // Update task status
  socket.on("update_task_status", async (data, callback) => {
    try {
      const { task, status } = data;

      const _status = await prisma.taskStatus.findFirst({
        where: {
          name: status,
        },
      });
      if (_status) {
        const response = await updateTaskStatus(
          task.id,
          _status.id,
          `Task added in ${status}`
        );
        if (response) {
          await getDesignerBucket({ designerId: data.task.designerId });
          let smeIds = [];
          for (const sme of task?.client?.smes) {
            smeIds.push(sme.smeId);
          }

          if (smeIds) {
            let socketIds = [];
            for (const _id of smeIds) {
              const socketId = await redis.get(`user:${_id}`);
              await getSmeBucket({ smeId: _id });
              if (socketId) {
                socketIds.push(socketId);
              }
            }
            console.log("socketIds", socketIds);
            for (const socketId of socketIds) {
              io.to(socketId).emit("message_updated_task", task);
            }
          }

          callback({
            status: "success",
            message: "Status Updated Successfully",
          });
        } else {
          callback({ status: "error", message: "Status Update Failed" });
        }
      }
    } catch (err) {
      console.log(err);

      callback({ status: "error", message: "Status Update Failed" });
    }
  });

  //   reorder task in queue
  socket.on("on_reorder", async (data) => {
    try {
      const today = new Date().toISOString().split("T")[0];
      const { newOrderOfTasks, user } = data;
      // console.log("user : ", user);

      let designerIds = [];
      const smeId = user._id;
      let newOrderIdList = [];
      for (const item of newOrderOfTasks) {
        const { id, designerId } = item;
        // Check if designerId is not already in the array before pushing
        if (!designerIds.includes(designerId)) {
          designerIds.push(designerId);
        }
        newOrderIdList.push(`${id}`);
      }
      // console.log("new reorder list", newOrderIdList);
      let pattern = ``;
      if (user.role.name.toLowerCase() === "sme") {
        if (user.head) {
          pattern = `designerId:*:smeId:*:bucket:${today}`;
        } else {
          pattern = `designerId:*:smeId:${smeId}:bucket:${today}`;
        }
      } else if (
        user.role.name.toLowerCase() === "super admin" ||
        user.role.name.toLowerCase() === "admin"
      ) {
        pattern = `designerId:*:smeId:*:bucket:${today}`;
      }

      const { resultWithKey } = await getDataByKeyPattern({ pattern: pattern });
      // console.log("Before Reordering:", resultWithKey);

      // Reorder `resultWithKey` based on `newOrderIdList`
      const reorderedResult = newOrderIdList.map((id) =>
        resultWithKey.find((item) => item.value === id)
      );

      // console.log("after Reordering:", reorderedResult);

      for (let index = 0; index < reorderedResult.length; index++) {
        const item = reorderedResult[index];
        // console.log("item", item);

        await addTaskToBucket({
          key: item.key,
          order: index,
          id: item.value,
          reorder: true,
        });
      }

      for (const designerId of designerIds) {
        try {
          await getDesignerBucket({ designerId: designerId });
        } catch (error) {
          console.error(
            `Error fetching socket ID for designerId ${designerId}:`,
            error
          );
        }
      }
    } catch (error) {
      console.log(error);
    }
  });

  // remove task from designer bucket
  socket.on("remove_task_from_bucket", async (data, callback) => {
    try {
      const { task, user } = data;

      console.log("task", task);

      // find in bucket
      const pattern = `designerId:${task.designerId}:smeId:*:bucket:*`;
      const { resultWithKey } = await getDataByKeyPattern({ pattern: pattern });

      // Find the key containing this task
      for (const item of resultWithKey) {
        if (item.value === `${task.id}`) {
          await redis.zrem(item.key, `${task.id}`);
          break;
        }
      }

      // Update task status to removed/pending
      await updateTaskStatus(
        task.id,
        2, // Assuming 1 is the status ID for pending/removed
        "Task removed from bucket"
      );

      // Notify relevant users about the change
      const _newTask = await getTaskById(task.id);
      await getDesignerBucket({ designerId: task.designerId });
      await getSmeBucket({ smeId: user._id });

      callback({ status: "success", data: "Task removed successfully" });

      // remove from bucket

      // update status of task
    } catch (error) {
      callback({ status: "error", data: "Task Removed failed received!" });
    }
  });

  // message send
  socket.on("send_message", async (data, callback) => {
    try {
      const { task, user, message } = data;
      let res = await saveMessage({
        task: task,
        message: message,
        fromId: user._id,
      });

      if (res) {
        const _newTask = await getTaskById(task.id);
        let smeIds = [];

        task.client?.smes?.map((sme) => {
          smeIds.push(sme.smeId);
        });

        // if message successfully saved then check all ids connected to task like smes and designer
        let socketIds = [];
        let socketIdOfDesigner = await redis.get(`user:${task.designerId}`);
        if (socketIdOfDesigner) {
          socketIds.push(socketIdOfDesigner);
        }

        if (smeIds) {
          for (const _id of smeIds) {
            const socketId = await redis.get(`user:${_id}`);
            if (socketId) {
              socketIds.push(socketId);
            }
          }
        }
        for (const socketId of socketIds) {
          io.to(socketId).emit("message_updated_task", _newTask);
        }

        callback({ status: "success", data: "Message received!" });
      } else {
        callback({ status: "error", data: "Message saved failed received!" });
      }
    } catch (error) {
      callback({ status: "error", data: "Message saved failed received!" });
    }
  });


  // Add content to task
  socket.on("add_content_to_task", async (data, callback)=>{
    try {
      const {task, title ,contentUrl} = data;
      const _content = await prisma.taskContent.create({
        data:{
          task:{
            connect:{
              id: task.id
            }
          },
          title: title,
          contentUrl: contentUrl
        }
      })

      if(_content){
        const _newTask = await getTaskById(task.id);
        let smeIds = [];
        task.client?.smes?.map((sme)=>{
          smeIds.push(sme.smeId);
        });


        // if contentLink successfully saved then check all ids connected to task like smes and designer
        let socketIds = [];
        let socketIdOfDesigner = await redis.get(`user:${task.designerId}`);
        if(socketIdOfDesigner){
          socketIds.push(socketIdOfDesigner);
        }

        if (smeIds) {
          for (const _id of smeIds) {
            const socketId = await redis.get(`user:${_id}`);
            if (socketId) {
              socketIds.push(socketId);
            }
          }
        }

        for (const socketId of socketIds) {
          io.to(socketId).emit("message_updated_task", _newTask);
        }
      }
    } catch (error) {
      callback({status: "error", data: "Content add failed"});
    }finally{
      callback({status: "success", data: "Content added successfully"});
    }
  })

  // post_link_submit
  socket.on("post_link_submit", async (data, callback) => {
    try {
      const { task, postLink } = data;
      const _postLink = await prisma.taskPostLink.create({
        data:{
          task:{
            connect:{
              id: task.id
            }
          },
          url: postLink
        }
      })
      if (_postLink) {
        const _newTask = await getTaskById(task.id);
        let smeIds = [];

        task.client?.smes?.map((sme) => {
          smeIds.push(sme.smeId);
        });

        // if message successfully saved then check all ids connected to task like smes and designer
        let socketIds = [];
        let socketIdOfDesigner = await redis.get(`user:${task.designerId}`);
        if (socketIdOfDesigner) {
          socketIds.push(socketIdOfDesigner);
        }

        if (smeIds) {
          for (const _id of smeIds) {
            const socketId = await redis.get(`user:${_id}`);
            if (socketId) {
              socketIds.push(socketId);
            }
          }
        }

        for (const socketId of socketIds) {
          io.to(socketId).emit("message_updated_task", _newTask);
        }
        callback({ status: "success", data: "Post link updated" });
      } else {
        callback({
          status: "error",
          data: "Post Link Update failed received!",
        });
      }
    } catch (error) {
      callback({ status: "error", data: "Post Link Update failed received!" });
    }
  });

  // add task to designer bucket
  const addTaskToDesignerBucket = async (data) => {
    try {
      const { designerId, id } = data.task;
      const { smeId } = data.user;
      const today = new Date().toISOString().split("T")[0];
      let _getKey = `designerId:${designerId}:smeId:*`;
      const keys = await new Promise((resolve, reject) => {
        redis.keys(_getKey, (err, reply) => {
          if (err) return reject(err);
          resolve(reply);
        });
      });
      let designerBucket = [];
      const { resultWithKey } = await getDataByKeyPattern({ pattern: _getKey });
      designerBucket = resultWithKey;
      if (designerBucket.length > 0) {
        designerBucket.push({
          key: `designerId:${designerId}:smeId:${smeId}:bucket:${today}`,
          value: `${id}`,
        });

        for (let index = 0; index < designerBucket.length; index++) {
          const item = designerBucket[index];
          await addTaskToBucket({
            key: item.key,
            order: index,
            id: item.value,
          });
        }
      } else {
        // console.log("Bucket is empty");

        const key = `designerId:${designerId}:smeId:${smeId}:bucket:${today}`;
        await addTaskToBucket({ key: key, order: 0, id: id });
      }
    } catch (error) {
      console.log(error);
    }
  };

  //   get sme bucket , this will send task to sme
  const getSmeBucket = async ({ smeId }) => {
    try {
      let _result = [];
      const today = new Date().toISOString().split("T")[0];
      const pattern = `designerId:*:smeId:${smeId}:bucket:${today}`;
      const { result } = await getDataByKeyPattern({ pattern: pattern });

      const tasks = await getTasksByIdList({ idList: result });

      const socketIdOfSME = await redis.get(`user:${smeId}`);
      if (socketIdOfSME) {
        io.to(socketIdOfSME).emit("tasks_in_queue", tasks);
        //   socket.emit('tasks_in_queue', tasks);
      }
    } catch (error) {
      console.log(error);
    }
  };

  //   Get designer bucket, this will send task to particular designer
  const getDesignerBucket = async ({ designerId }) => {
    try {
      let _result = [];
      const today = new Date().toISOString().split("T")[0];
      const pattern = `designerId:${designerId}:smeId:*:bucket:${today}`;
      const { result } = await getDataByKeyPattern({ pattern: pattern });

      // console.log("result", result);

      const tasks = await getTasksByIdList({ idList: result });

      // console.log("tasks", tasks);

      const socketIdOfDesigner = await redis.get(`user:${designerId}`);
      if (socketIdOfDesigner) {
        io.to(socketIdOfDesigner).emit("tasks_in_queue", tasks);
      }
    } catch (error) {
      console.log(error);
    }
  };

  // const get all bucket
  const getAllBucket = async () => {
    try {
      let _result = [];
      const today = new Date().toISOString().split("T")[0];
      const pattern = `designerId:*:smeId:*:bucket:${today}`;
      const { result } = await getDataByKeyPattern({ pattern: pattern });
      const tasks = await getTasksByIdList({ idList: result });

      socket.emit("tasks_in_queue", tasks);
    } catch (error) {
      console.log(error);
    }
  };

  //   Add task to bucket
  const addTaskToBucket = async ({ key, order, id, reorder = false }) => {
    try {
      // const key = `designerId:${designerId}:smeId:${smeId}:bucket:${today}`;
      await redis.zadd(key, parseInt(order), `${id}`);
      redis.expire(key, 60 * 60 * 12);

      // after add wee need to update status o task with log

      // get task by task id
      const task = await getTaskById(id);

      if (!reorder) {
        let updatedTaskStatusId = 3;
        // if task found then get task status
        if (task) {
          // after get task status then set task status in queue
          // after get task status then set task status in queue and update log
          const _res = await updateTaskStatus(
            id,
            updatedTaskStatusId,
            "Task Added in queue"
          );
        }
      }
    } catch (error) {
      console.log(error);
    }
  };

  //  get bucket data by key pattern
  const getDataByKeyPattern = async ({ pattern }) => {
    let resultWithKey = [];
    let result = [];
    const keys = await new Promise((resolve, reject) => {
      redis.keys(pattern, (err, reply) => {
        if (err) return reject(err);
        resolve(reply);
      });
    });
    if (keys.length > 0) {
      for (const key of keys) {
        const _bucket = await new Promise((resolve, reject) => {
          redis.zrange(key, 0, -1, (err, reply) => {
            if (err) return reject(err);
            resolve(reply);
          });
        });
        if (_bucket.length > 0) {
          _bucket.forEach((value) => {
            resultWithKey.push({ key: key, value: value });
            result.push(value);
          });
        }
      }
    }

    return { resultWithKey, result };
  };

  // update task priority of designer

  // Remove task from designers bucket

  // get buckets of designer

  // get all designers bucket

  // Handle disconnection
  socket.on("disconnect", async () => {
    try {
      const keys = await redis.keys("user:*");
      for (const key of keys) {
        const storedSocketId = await redis.get(key);

        if (storedSocketId === socket.id) {
          // Delete the Redis entry
          const userId = key.split(":")[1];

          const user = await getUserById(userId);
          socket.broadcast.emit("user_disconnected", user);

          await redis.del(key);
          const _keys = await redis.keys("user:*");
          let _users = [];
          for (const key of _keys) {
            const id = key.split(":")[1];
            _users.push(id);
          }
          io.emit("online_users", _users);
          // console.log(`Removed ${key} for disconnected socket ${socket.id}`);
          break;
        }
      }
    } catch (error) {
      console.error("Error removing from Redis:", error);
    }
    console.log("Client disconnected:", socket.id);
  });
});

// Start the server
server.listen(PORT, () => console.log(`Server started on port ${PORT}`));
