module.exports = {
  MONGO_URI:
    "mongodb+srv://2022krishnabasak:Krishnabasak01@cluster0.rjqrjan.mongodb.net/tbm_work_flow",
};
