module.exports = {
  SECRET_KEY: "tbm",
  EXPIRES_IN: "1h",
};
